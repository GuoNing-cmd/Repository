// alert("new detail");
//*************************************  使用vue和页面数据进行双向绑定   ***********************************************
var cont = new Vue({
    el: "#contDetail",
    data: {
        url: "",
        contNo: "",
        interactive: "",
        newUrl: "",
        appnt: {
            username: "",
            appId: "",
            name: "",
            sex: "",
            birthday: "",
            age: "",
            riskLevels: "",
            agentCode: "",
            isEld: false,
            isFirst: false,
            isOndo: false,
            appntNo: ""
        },
        productList: [],
        talkList: [],
        type:false,
        riskLevelType:[]
    }
});
//视频解密的密钥
var keydata={};
$(function () {
    $(document).bind("contextmenu",function(e) {
        return false;
    });
    if (!G.localIp) {
        G.localIp = "127.0.0.1:15962";
    }
    $("#myModal").load("modal.html");
    $.post("/easyRecordHS/business/initSelect", function (re) {
        cont.riskLevelType = re.data.riskLevelType;
    });
    //回显保单详情
    var contNo = sino.getUrlParam('contNo');
    if (contNo != "") {
        cont.contNo = base64.decode(contNo);
        $.ajax({
            url: "/easyRecordHS/echo/echoInfo",
            data: JSON.stringify({contNo: cont.contNo}),
            contentType: "application/json;",
            type: "post",
            success: function (result) {
                if (!result.success) {
                    return;
                }
                cont.appnt = result.data.appnt;
                if (cont.appnt.sex == 0) {
                    $("#man").attr("checked", "checked");
                } else {
                    $("#woman").attr("checked", "checked");
                }
                video.video.contNo = cont.contNo;
                video.talks = result.data.talks;
                cont.interactive = result.data.interactive;
                cont.officeCode=result.data.officeCode;
                cont.url = result.data.url;
                cont.productList = result.data.productInfo;
                cont.busiNum = result.data.busiNum;
                var messages = result.data.messages;
                if (cont.interactive == "L" && !sino.checkIsNull(messages)) {
                    $("#title").html(messages.title);
                    $("#message").val(messages.message);
                    $("#remarks").val(messages.remarks);
                }
                if(cont.interactive=="S"){
                    keydata.key1=result.data.key1;
                }
                showVideo(cont.interactive, cont.url);
            }
        })
    }
    //屏幕适应
    window.onresize = function () {
        if ($(document).width() <= 800) {
            $("#confirm").css({"width": "80%"});
            $("#confirm button").css({"width": "40%"});
        } else {
            $("#confirm").css({"width": "48%"});
            $("#confirm button").css({"width": "45%"});
        }
    }
    //切换拍照和播放视频
    $("#open").click(function () {
			// alert(111)
        if(cont.interactive=="S"){
            $("#scan").toggle();
            if(VideoMain==undefined){
                $("#newVideo").hide();
                $("#scan").show();
                $("#videoDiv").hide();
                // setTimeout(function () {
                // },1000);
                return;
            }
            $("#videoDiv").toggle();
        }else if(cont.interactive=="L"){
            $("#videoDiv").hide();
            $("#video").show();
            if($("#scan").is(':hidden')){
                $("#scan").show();
                $("#newVideo").hide();
            }else{
                $("#newVideo").show();
                colseScan();
                $("#scan").hide();
            }
        }
    });

    $(".go").click(function () {
        Unload();
        window.location = "videoSearch.html";
    });

    //切换基本信息和文件补充
    $(".qie").click(function () {
        $(".leftInformation").toggle();
    });
    //拍照
    $(".detailsBottomDiv").click(function () {
        if (isScanOpen === false) {
            $("#newVideo").hide();
            $("#scan").show();
            $("#videoDiv").hide();
            setTimeout(function () {
                // OpenVideoMain();
                scanInit();
            }, 1000);
            return;
        }
        scanw();
    });

    //修改用户信息
	$(".preservation").click(function () {
		var msg = "";
        if (cont.appnt.appId == "") {
            msg += "客户号不能为空<br/>";
        } else {
            var reg = /^\d{9}$/
            if (!reg.test(cont.appnt.appId)) {
                msg += "客户号必须是9位数字<br/>";
			}
        }
		var reg = /^([\u4e00-\u9fa5]+)|(.?)$/;
        if (cont.appnt.name == "") {
            msg += "客户姓名不能为空<br/>";
        } else {
            if (!reg.test(cont.appnt.name)) {
                msg += "客户姓名格式有误<br/>";
			}
		}
        if (msg != "") {
			sino.alert(msg);
			return;
		}
		cont.appnt.sex = $("[type='radio']:checked").val();
        $.ajax({
            url: "/easyRecordHS/echo/updateAppnt",
            data: JSON.stringify(cont.appnt),
            contentType: "application/json;",
            type: "post",
            success: function (result) {
                if (result.success) {
                    sino.alert("修改成功");
                }
            }
		});
    });

    //取消视频的右键菜单
    $("video").bind("contextmenu", function () {
        return false;
    });
    //重新录制
    $("#updateVideo").click(function () {
        if (cont.interactive == "S") {
            $.getJSON("http://" + G.localIp + "/easyrecordHS/deleteVideo?callback=?",{path:cont.url});
                window.location = "index.html?contNo=" + contNo;
                return;
        }
        colseScan();
        $("#scan").hide();
        $("#videoDiv").hide();
        $("#newVideo").show();
        setTimeout(function () {
            // OpenVideoAssist2();
            reVideo();
        }, 1000);
        $(this).hide();
        $("#stopVideo").show();
        $(".add").attr("disabled","disabled");
    });

    $("#stopVideo").click(function () {
        sino.confirm("是否已经完成录制", "video");
    });

    //切换为话术
    $("#talk").click(function () {
        $(this).addClass("essentialColor productColor");
        $("#zhi").removeClass("essentialColor productColor");
        $("#zhi").addClass("qualityCheck");
        $(".talkList").show();
        $(".qualityTesting").hide();
    });
    //切换为质检
    $("#zhi").click(function () {
        $(this).addClass("essentialColor productColor");
        $("#talk").removeClass("essentialColor productColor");
        $("#talk").addClass("qualityCheck");
        $(".talkList").hide();
        $(".qualityTesting").show();
    });
    $(".fileBtn").click(function () {
        var newFileInput = "<input id='uploaderInput' style='display: none' type='file' name='file'   />";
        $("#fileForm").append($(newFileInput));
        $("#uploaderInput").bind("change", function () {
            var arr = this.value.split(',');
            for (var i = 0; i < arr.length; i++) {
                var div = "<div class='callBack'><div>文件:</div> <input readonly class='callBackContent'value='" + arr[i] + "' /><span class='deleteFile' onclick='isDelete(this)'>&times;</span></div>";
                $(".callBackBox").append(div);
            }
            $(this).removeAttr("id");
        });
        $("#uploaderInput").click();
    });


    //上传
    $(".add").click(function () {
        // alert("add start");
        var $pictures = $(".imgUrl");
        var $files = $(".callBackContent");
        //如果保单状态为整改,替换成新的保单号
        alert("cont.interactive :" + cont.interactive );
        if (cont.interactive == "L") {
            //如果newContNo不存在,代表没重录视频
            if(!video.newContNo){
                cont.type=true;
                var flag=skipVideo();
                if(!flag){
                    Unload();
                    setTimeout(function () {
                        window.location = "videoSearch.html";
                    },1500);
                    return;
                }
            }
            //如果附件和图片为空,则跳过上传文件
            if($files.length == 0 && $pictures.length == 0 && sino.checkIsNull($("#contents").val())){
               if(!cont.type){
                   skipPictrue();
               }else{
                   sino.alert("整改单必须补充资料或视频");
                   return;
               }
            }
        }else{
            if ($files.length == 0 && $pictures.length == 0) {
                sino.alert("请补充文件信息再上传!");
                return;
            }
        }
        $(".add").attr("disabled","disabled");
        //获取附件和图片路径
        var pictures = new Array();
        for (var i = 0; i < $pictures.length; i++) {
            pictures.push($($pictures[i]).attr("name"));
        }

        if (pictures.length != 0) {
            $("[name='imgsPath']").val(pictures.join(','));
        }
        if(cont.interactive == "L"){//如果为整改单,contNo为新的contNo
            cont.contNo=video.newContNo;
        }
        $("[name='contNo']").val(cont.contNo);
        $("[name='content']").val($("#contents").val());
        $("[name='type']").val(cont.type);
        var form = new FormData(document.getElementById("fileForm"));
        $.ajax({
            url: "/easyRecordHS/img/uploadImg",
            type: "post",
            data: form,
            processData: false,
            contentType: false,
            async: false,
            success: function (result) {
                if (result.success) {
                    sino.alert(result.messages, "videoSearch.html");
                } else {
                    sino.alert("上传失败");
                    console.log("上传失败{" + JSON.stringify(result) + "}");
                    $(".add").removeAttr("disabled");
                }
            }
        });
    });
})


/**
 * 如果目录下面有图片回显
 * @param path
 */
function jsonpCallback(json) {
    if(!json.success){
        if(sino.checkIsNull(json.paths)){
            return;
        }
        var pathArr=json.paths.split(',');
        var $img;
        var picPath;
        for(var i=0;i<pathArr.length;i++){
            picPath=pathArr[i];
            console.log(pathArr[i]);
             $img = $(" <div class='detailsDiv' style='position: relative'><a href='" + picPath + "'><img  Name='" + picPath + "'  style='width: 10rem' class='imgUrl'  /></a><img class='delPic' style='position: absolute;width: 20px;' src='img/delete.png' onclick='isDeletePic(this)' /> </div>");
            $img.find("a").on('click', openPictrue);
            $img.find("a img").attr("src", "http://" + G.localIp + "/easyrecordHS/showImage?fileName=" + picPath + "&t=" + Math.random()).show();
            $(".gallery").append($img);
        }
    }
}

/**
 * 判断保单状态
 * 如果为文件待补充S 播放本地视频
 * 如果为保单整改L 播放云上视频
 */
function showVideo(interactive, url) {
    cont.picUrl = sino.getPath("pictrue") + sino.replaceBusiNum(cont.busiNum);
    $.getJSON("http://" + G.localIp + "/easyrecordHS/createPicDirectory?callback=?", {path:cont.picUrl});
    if (interactive == "L") {
        var option = {
            "width": 640,
            "height": 480,
            //...可选填其他属性
            "third_video": {
                "urls": {
                    220: url
                }
            }
        };
        $("#bu").hide();
        $(".preservation").hide();
        $("#appId").attr("disabled", "disabled");
        $("#userName").attr("disabled", "disabled");
        $("#appId").addClass("fff");
        $("#userName").addClass("fff");
        $("#cosVideo").show();
        $("#skipVideo").removeClass("hidden");
        $("#skipPictrue").removeClass("hidden");
        $("[name=\"sex\"]").attr("disabled", "disabled");
        $("#zhi").removeClass("hidden");
        new qcVideo.Player("cosVideo", option);
    } else if (interactive == "S") {
        $("#first").removeClass("hidden");
        if (G.officeCode != cont.officeCode) {
            sino.alert("录制视频的理财室编号和当前不一致<br/>无法回看视频");
            return;
        }
        //先解密再播放视频
        cont.newUrl = url.substring(0, url.lastIndexOf("//") + 2) + sino.getDateTime() + ".mp4";
        $.ajax({
            url: "http://" + G.localIp + "/easyrecordHS/unFileEncrypter",
            data: {
                url: url,
                newUrl: cont.newUrl,
                key1: keydata.key1
            },
            type: "get",
            dataType: "jsonp",
            //传递给请求处理程序，用以获得jsonp回调函数名的参数名(默认为:callback)
            jsonp: "callback",//传递给请求处理程序或页面的，用以获得jsonp回调函数名的参数名(一般默认为:callback)
            jsonpCallback: "jsonpCallback",
            success: function () {
                console.log("解密正常返回");
                $("#localVideo").attr("src", "http://" + G.localIp + "/easyrecordHS/showVideo?fileName=" + cont.newUrl);
                $("#localVideo").show();
            },
            error: function (a, b, c) {
                console.log("解密异常返回");
                $("#localVideo").attr("src", "http://" + G.localIp + "/easyrecordHS/showVideo?fileName=" + cont.newUrl);
                $("#localVideo").show();
            }
        });
    }
}

//拍照的方法
function scanw() {
    var Name = cont.picUrl + "//" + sino.getDateTime() + ".jpg";
    // alert(Name+1);
    var ret ;
    // var spath = "D:\\el_file\\" + Math.random() + ".jpg";
    ret = ViewMain1.Scan(0,Name,0);//param:{主摄像头 路径} 拍照
    if(0 == ret)
    {
        alert("拍照成功，路径为:" + Name);
        var $img = $(" <div class='detailsDiv' style='position: relative'><a href='" + Name + "'><img  Name='" + Name + "'  style='width: 10rem' class='imgUrl'  /></a><img class='delPic' style='position: absolute;width: 20px;' src='img/delete.png' onclick='isDeletePic(this)' /> </div>");
        $img.find("a").on('click', openPictrue);
        $img.find("a img").attr("src", "http://" + G.localIp + "/easyrecordHS/showImage?fileName=" + Name + "&t=" + Math.random()).show();
        $(".gallery").append($img);
    }
    else
    {
        alert("拍照失败");
    }

}
// function Scan() {
//     if (VideoMain) {
//         var imageList = VideoMain.CreateImageList(0, ViewMain.GetView());
//         if (imageList) {
//             ViewMain.PlayCaptureEffect();
//             // alert("AFTER CALL ViewMain.PlayCaptureEffect()")
//             var image = imageList.GetImage(0);
//             var Name = cont.picUrl + "//" + sino.getDateTime() + ".jpg";
//             image.Save(Name, 0);
//             image.Destroy();
//             image = null;
//             var $img = $(" <div class='detailsDiv' style='position: relative'><a href='" + Name + "'><img  Name='" + Name + "'  style='width: 10rem' class='imgUrl'  /></a><img class='delPic' style='position: absolute;width: 20px;' src='img/delete.png' onclick='isDeletePic(this)' /> </div>");
//             $img.find("a").on('click', openPictrue);
//             $img.find("a img").attr("src", "http://" + G.localIp + "/easyrecordHS/showImage?fileName=" + Name + "&t=" + Math.random()).show();
//             $(".gallery").append($img);
//         } else {
//             // alert("Scan() 201")
//         }
//     } else {
//         // alert("Scan():  ~~ VideoMain is UNDEFINE")
//     }
// }



//根据要整改的contNo生成新的contNo
function getNewContNo() {
    var newContNo = "";
    var flag=false;
    $.ajax({
        url: "/easyRecordHS/rerecord/rerecordCont",
        data: JSON.stringify({contNo: video.video.contNo}),
        contentType: "application/json;",
        type: "post",
        async: false,
        success: function (result) {
            if (result.success){
                newContNo = result.data.newContNo;
                flag=true;
            }else{
                sino.alert("此单不需要整改");
            }
        }
    });
    video.newContNo = newContNo;
    return flag;
}

//完成录制保存视频
function saveVideo() {
    var data = {
        video: video.video,
        picture: video.picture
    }
   var flag=getNewContNo();
    if(!flag){
        Unload();
        $.getJSON("http://" + G.localIp + "/easyrecordHS/deleteVideo?callback=?", {newUrl: video.video.oldUrl});
            setTimeout(function () {
                window.location = "videoSearch.html";
            },1500);
        return;
    }
    video.video.agentCode=G.agentCode;
    video.video.contNo =video.newContNo;
    video.picture.contNo = video.video.contNo;
    var $talk = $(".taskCheck");
    var $qualityZn = $(".openTop");
    for (var i = 0; i < $talk.length; i++) {
        video.picture.pkId.push($talk[i].value);
        video.picture.timeNode.push($($talk[i]).attr("name"));
        video.picture.qualityZn.push($($qualityZn[i]).html());
    }
    $('#myModal').hide();
    $("#newVideo").hide();
    $("#scan").show();
    $(".add").removeAttr("disabled","disabled");
    colseVideo();
        video.video.endDate = sino.getDateTime('1');
        video.video.timeLength = time;
    $.ajax({
        url: "/easyRecordHS/policy/saveVideo",
        data: JSON.stringify(data),
        contentType: "application/json;",
        type: "post",
        success: function (result) {
            if (result.success) {
                sino.alert("保存成功");
                $("#first").removeClass("hidden");
                $(".leftInformation:eq(0)").hide();
                $(".qie").show();
                $("#bu").show();
            } else {
                sino.alert("保存失败");
            }
        }
    });
}

function isDelete(obj) {
    sino.confirm("确认要删除附件吗？", "deleteFile", obj);
}

//删除附件
function deleteFile(obj) {
    var index = $(obj).parent().index();
    $(obj).parent().remove();
    $($("#fileForm").find("[type='file']").get(index)).remove();
    sino.alert("删除成功");
}



//跳过录视频
function skipVideo() {
    console.log("skipVideo  start");
   var flag=getNewContNo();
   if(!flag){
       return false;
   }
    var data = {
        contNo: video.video.contNo,
        newContNo: video.newContNo
    }
    $.ajax({
        url: "/easyRecordHS/rerecord/ignoreVideo",
        data: JSON.stringify(data),
        contentType: "application/json;",
        type: "post",
        async: false,
        success: function (result) {
            if (result.success) {
                console.log("skipVideo success  true");
            } else {
                console.log("skipVideo success  false");
                console.log(JSON.stringify(result));
            }
        }
    });
   return true;
}

//跳过上传图片
function skipPictrue() {
    console.log("skip pictrue start");
    var data = {
        contNo: cont.contNo,
        newContNo: video.newContNo,
        type:cont.type
    };
    $.ajax({
        url: "/easyRecordHS/rerecord/ignoreFile",
        data: JSON.stringify(data),
        contentType: "application/json;",
        type: "post",
        async: false,
        success: function (result) {
            if (result.success) {
                console.log("skip pictrue  success true");
                sino.alert("保存成功!", "videoSearch.html", "1000");
            } else {
                console.log("skip pictrue  success false");
                console.log(JSON.stringify(result));
            }
        }
    });
};


function isDeletePic(obj) {
    sino.confirm("确认要删除照片吗？", "deletePic", obj);
}
//删除照片
function  delPic(obj) {
     var $parent=$(obj).parent();
     var url=$parent.find("img").attr("name");
    $.getJSON("http://" + G.localIp + "/easyrecordHS/deleteVideo?callback=?", {newUrl:url});
    $parent.remove();
    sino.alert("删除成功");
}
var audioI=0;
var audioSum=0;
var audioAvg=0;
var img="";
//根据实时音频获取音量大小
setInterval(function () {
    if(audioSum==0){
        return;
    }
    var audioAvg=Math.round(audioSum/audioI/100);
    switch (audioAvg){
        case 0:
            img="img/audio/audio0.png";
        case 1:
            img="img/audio/audio1.png";
            break;
        case 2:
            img="img/audio/audio2.png";
            break;
        case 3:
            img="img/audio/audio3.png";
            break;
        case 4:
            img="img/audio/audio4.png";
            break;
        case 5:
            img="img/audio/audio5.png";
            break;
        case 6:
            img="img/audio/audio6.png";
            break;
        case 7:
            img="img/audio/audio7.png";
            break;
        case 8:
            img="img/audio/audio8.png";
            break;
        case 9:
            img="img/audio/audio9.png";
            break;
        default:
            img="img/audio/audio10.png";
            break;
    }
    $("#audioImg").attr("src",img);
    audioI=0;
    audioSum=0;
},1000);


function banBackSpace(e){
    var ev = e || window.event;
    //各种浏览器下获取事件对象
    var obj = ev.relatedTarget || ev.srcElement || ev.target ||ev.currentTarget;
    //按下Backspace键
    if(ev.keyCode == 8){
        var tagName = obj.nodeName //标签名称
        //如果标签不是input或者textarea则阻止Backspace
        if(tagName!='INPUT' && tagName!='TEXTAREA'){
            return stopIt(ev);
        }
        var tagType = obj.type.toUpperCase();//标签类型
        //input标签除了下面几种类型，全部阻止Backspace
        if(tagName=='INPUT' && (tagType!='TEXT' && tagType!='TEXTAREA' && tagType!='PASSWORD')){
            return stopIt(ev);
        }
        //input或者textarea输入框如果不可编辑则阻止Backspace
        if((tagName=='INPUT' || tagName=='TEXTAREA') && (obj.readOnly==true || obj.disabled ==true)){
            return stopIt(ev);
        }
    }
}
function stopIt(ev){
    if(ev.preventDefault ){
        //preventDefault()方法阻止元素发生默认的行为
        ev.preventDefault();
    }
    if(ev.returnValue){
        //IE浏览器下用window.event.returnValue = false;实现阻止元素发生默认的行为
        ev.returnValue = false;
    }
    return false;
}

$(function(){
    //实现对字符码的截获，keypress中屏蔽了这些功能按键
    document.onkeypress = banBackSpace;
    //对功能按键的获取
    document.onkeydown = banBackSpace;
})